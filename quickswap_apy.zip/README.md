# Quickswap APY Calculator Chrome/Brave Extension

This is a browser extension that calculates the APYs on quickswap.exchange/#/quick

Click the extension and the APYs will load

This is what the website will look like after the script has run

![](images/quick.png)
